export interface IAuthToken {
  token: string
}
