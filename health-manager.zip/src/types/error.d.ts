declare global {
  export interface Error {
    status: number
  }
}
